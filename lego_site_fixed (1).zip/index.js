
let scp = 999;
let star_wars_day = 4;
let SW_MONTH = 5;
alert(scp + SW_MONTH * star_wars_day);
